/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assertion;

/**
 *
 * @author Lee
 */
public class Assertion {

    /**
     * @param args the command line arguments
     */
    private String pQuantity;		
    private String pColour;		
    private String pSize;
    private String promo;
    private String sPrice;
    
    public Assertion(String qtt, String clr, String size, String pro, String pri){
        pQuantity = qtt;		
        pColour = clr;		
        pSize = size;
        promo = pro;
        sPrice = pri;
    }
    
    private boolean mysql_query(){
	if(pQuantity.isEmpty() || pColour.isEmpty() || promo.isEmpty() || sPrice.isEmpty()) 
	{						
            return false;
	}
	else{                        
            return true;
	}   					
    }
	   
    public static void main(String[] args) {
        // TODO code application logic here        
        Assertion assert1 = new Assertion("","white","S","yes","55.50");                
        boolean status = assert1.mysql_query();
        assert status : "Field is empty";

        System.out.println("All field is not empty \n");                        
    }
    
}
