/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package invariant;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JFrame;
import javax.swing.JTextField;
import java.util.Scanner;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
/**
 *
 * @author Lee
 */
public class Invariant implements ActionListener{

    /**
     * @param args the command line arguments
     */                          
    static class MKeyListener extends KeyAdapter {        
        public boolean isDigit;
        static public JTextField textfield;               
        
        static public void setTextField(JTextField tt){
            textfield = tt;
        }
                
        @Override
        public void keyReleased(KeyEvent e) {                                   
            try{                
                if(!Character.isDigit(e.getKeyChar())){                   
                    if(textfield.getText().length() > 0){
                        JOptionPane.showMessageDialog(null, "Please enter number only.", "InfoBox: " + "Error", JOptionPane.INFORMATION_MESSAGE);
                        String text = textfield.getText().substring(0,textfield.getText().length()-1);                        
                        textfield.setText(text);
                    }                    
                }                    
            }catch (NumberFormatException ex) {
                //handle exception here                       
            }                                           
        }                        
    }             
    
    public void actionPerformed (ActionEvent e) {  
        JTextField textfield = MKeyListener.textfield;
        
        try{
            System.out.println(textfield.getText().length());
            if(textfield.getText().length() > 10){                   
                if(textfield.getText().length() > 0){
                    JOptionPane.showMessageDialog(null, "Maximum 10 numbers are allowed", "InfoBox: " + "Error", JOptionPane.INFORMATION_MESSAGE);
                    String text = textfield.getText().substring(0,10);                        
                    textfield.setText(text);
                }                    
            }                    
        }catch (NumberFormatException ex) {
            //handle exception here                       
        }  
    }
    
    public static void main(String[] args) {
        // TODO code application logic here                            
         SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Invariant().newWindow();
            }
        });
    }      
    
    public void newWindow(){
        JFrame f=new JFrame("Button Example");         
        
        JButton b=new JButton("Submit");    
        b.setBounds(100,100,140, 40);  
        b.addActionListener(this);
                                
        JLabel label = new JLabel();		
        label.setText("Phone Number :");
        label.setBounds(10, 10, 100, 100);
                                
        JLabel label1 = new JLabel();
        label1.setBounds(10, 110, 200, 100);
                       
        JTextField textfield = new JTextField();
        textfield.setBounds(110, 50, 130, 30);    
        MKeyListener.setTextField(textfield);
        textfield.addKeyListener(new MKeyListener());
        
        f.add(label1);
        f.add(textfield);
        f.add(label);
        f.add(b);    
        f.setSize(300,300);    
        f.setLayout(null);            
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
        f.setLocationRelativeTo(null);     
        f.setVisible(true);   
    }
}
